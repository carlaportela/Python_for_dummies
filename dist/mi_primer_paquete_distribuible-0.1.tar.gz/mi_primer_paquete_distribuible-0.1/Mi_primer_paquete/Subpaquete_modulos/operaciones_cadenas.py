def unirCadenas(cadena1, cadena2):
    print("Unión de cadenas: " + cadena1 + " " + cadena2)

def longitudCadena(cadena):
    print("Longitud de la cadena: " + str(len(cadena)))

def convertirMayusculas(cadena):
    print("Cadena en mayúsculas: " + cadena.upper())
    
def convertirMinusculas(cadena):
    print("Cadena en minúsculas: " + cadena.lower())